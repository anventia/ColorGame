import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ColorGame extends PApplet {

// Brendan Chen
// 2021/09/16
// Programming 12 Color Game

// Variables //
float scaleX;
float scaleY;

int mode;  // Mode Framework
final int INTRO    = 0;
final int GAME     = 1;
final int GAMEOVER = 2;
final int PAUSE    = 3;

PFont GilroyLight;  // Fonts
PFont GilroyBold;

float textLarge;
float strokeLarge;

String[] words;  // Color arrays
int[] colors;
int red = 0xffFF7D76;
int orange = 0xffFFAD76;
int yellow = 0xffFFFB76;
int green = 0xff78FF76;
int blue = 0xff76B9FF;
int purple = 0xffDA76FF;

final int countdown = 2;  // How many seconds for each word

int score = 0;  // Scoring
int highscore = 0;

PImage[] gif;  // Background Gif
int frames;
int loadFrame;

public void setup() {
  background(255);
  //fullScreen();    // Fullscreen
  
  // Should work with any size(); although it might break if height > width, and larger sizes make the gif lag in INTRO mode
  surface.setTitle("Programming 12 | ColorGame();");  // Sets window title
  surface.setResizable(true);  // Allows window to be resized
  cursor(1);
  
  frames = 189;  // Initialize Gif
  gif = new PImage[frames];
  int i = 0;
  while (i < frames) {
    String k = ""+i;  // Converts to string
    if (i < 100) k = "0"+i;  // Automatically converts 7 into 007 and 56 into 056 (to match gif naming)
    if (i < 10) k = "00"+i;
    
    gif[i] = loadImage("frame_"+k+"_delay-0.04s.gif"); 
    i += 1;
    if (i == 72) i += 1;  // Skip frame 072 because for some reason it's out of place in the animation
  }  // When GIF was converted into image sequence, it glitched and now it has a 'glitch' effect because it actually glitched
  
  mode = INTRO;  // Start with the Intro mode
  
  // Window Scaling Variables //
  scaleX = 1.0f/1000*width;  // Shapes coded for a 1000x700 display, multiply values by these to scale to other display sizes accordingly
  scaleY = 1.0f/700*height;  // For some reason, 1/700 returns 0, 1.0/700 returns the actual quotient
  textLarge = height/9;
  strokeLarge = height/35;
  
  GilroyLight = createFont("Gilroy-Light.otf", 100);
  GilroyBold = createFont("Gilroy-ExtraBold.otf", 100);
  textFont(GilroyLight);
   
  words = new String[6];  // Create lists
  colors = new int[6];
  
  words[0] = "red";     colors[0] = red;  //  Words and colors
  words[1] = "orange";  colors[1] = orange;
  words[2] = "yellow";  colors[2] = yellow;
  words[3] = "green";   colors[3] = green;
  words[4] = "blue";    colors[4] = blue;
  words[5] = "purple";  colors[5] = purple;
  
  initPuzzle();
}

public void draw() {
  switch(mode) {  // Mode Framework  
    case INTRO:     intro();      space = false; break;  // space = false; just in case space key is pressed when mode changes to intro or gameover
    case GAME:      ColorGame();       space = false; break;
    case GAMEOVER:  gameover();   space = false; break;
    case PAUSE:     paused();
  }
  // Updates Window Scaling Variables //
  scaleX = 1.0f/1000*width;
  scaleY = 1.0f/700*height;  
  textLarge = height/9;  
  strokeLarge = height/35;
}
// Variables
boolean space = false;
boolean yes = false;
boolean no = false;
boolean trueColor = false;
boolean falseColor = false;

public void mousePressed() {
  
}

public void mouseReleased() {

}

public void mouseClicked() {
  if (mode == GAME) {
    if (mouseX < width/2 && mouseY > height/2) yes = true;  // Game clicks
    if (mouseX > width/2 && mouseY > height/2) no = true;
  }
}


public void keyPressed() {
  if (key == CODED) {  // Detects left and right arrows
    switch(keyCode){
      case LEFT: yes = true; trueColor = true; break; 
      case RIGHT: no = true; falseColor  = true; break;
    }
  }
}

public void keyReleased() {
  if (key == CODED) {
    switch(keyCode){
      case LEFT: yes = false; trueColor = false; break;
      case RIGHT: no = false; falseColor  = false; break;
    }
  }
  if (key == ' ') space = true;
}
String puzzle;
int pColor;
boolean match;
float timer;
float timerX;
String[] displayList;
String display;
float selection;
float prevValue = 0;
int blink = 0;
boolean reverse = false;

public void initPuzzle() {  // Initializes puzzle
  timer = countdown;
  timerX = width;
  match = false;
  yes = false;
  no = false;
  selection = 2.0f;
  display = "";
  prevValue = 0;
  
  int a = PApplet.parseInt(random(0,6));  // Random word
  int b = PApplet.parseInt(random(1,11));  // Match or do not match
  if (b > 5) match = true;
  puzzle = words[a];  // Pick a random word
  if (match) {pColor = colors[a];} else {pColor = colors[( a + (int)random(1,6)) % 6];} 
}


public void drawPuzzle() {  // Draws out the word, letter by letter.
  int letters = puzzle.length();  // Number of letters in puzzle
  displayList = new String[letters];  // List of letters
  int i = 0;
  prevValue = floor(selection);  // Selection is incremented by decimals, this detects when it goes from 3.xxxx to 4.xxxx
  
  if(floor(selection) != letters+2) selection += 1.0f/5;  // Only increases if all letters not drawn yet  // 1.0/x determines the speed
  if(floor(selection) != prevValue) {  // If selection changes from 3.xxxx to 4.xxxx
    display = "";  
    while(i < floor(selection)-2) {  // Adds letters to display string one by one, 
      displayList[i] = ""+puzzle.charAt(i);
      display += displayList[i];
      i += 1;
    }
  }
  textAlign(LEFT);
  textFont(GilroyBold); 
  textSize(textLarge);  // Draws the text.
  fill(pColor);  
      
  if (blink <= 10)               text("> "+display+"_", width/7, height/4+15*scaleY+strokeLarge);  // Makes | character blink
  if (blink > 10 && blink <= 25) text("> "+display,     width/7, height/4+15*scaleY+strokeLarge);  // ^
  
  if(blink == 25) reverse = true;  // Makes blink go from 0-20 then 20-0...
  if (blink == 0) reverse = false;
  if (reverse == true) blink -= 1; else blink += 1;
}


public void ColorGame() {
  background(250);
  
  //fill(100);  // Dividing lines
  //stroke(100);
  //strokeWeight(2);
  //line(width/2,height/2, width/2,height);
  //line(0,height/2, width,height/2);  
  
  if(focused == false) {mode=PAUSE;} 
  
  // Background rectangles //
  fill(50);
  noStroke();
  rect(width/2,height*0.25f-strokeLarge*-0.25f, width-strokeLarge*2,height/2-strokeLarge*1.5f, strokeLarge);  // Display
  noStroke();
  if (trueColor) {fill(0xff90FF9C, 150);} else {noFill();}  // Highlight
  rect(width*0.25f+strokeLarge*0.5f, height*0.75f+strokeLarge*-0.25f, width/2-strokeLarge, height/2-strokeLarge*1.5f, strokeLarge,0,0,strokeLarge);  // true 
  if (falseColor) {fill(0xffFF9090, 150);} else {noFill();}  // Highlight
  rect(width*0.75f-strokeLarge*0.5f, height*0.75f+strokeLarge*-0.25f, width/2-strokeLarge, height/2-strokeLarge*1.5f, 0,strokeLarge,strokeLarge,0);  // false
  noFill();
  strokeWeight(5*scaleX);
  stroke(50);
  rect(width/2,height*0.75f+strokeLarge*-0.25f, width-strokeLarge*2-5*scaleX,height/2-strokeLarge*1.5f-5*scaleX, strokeLarge);  // Buttons
  
  if (mouseX < width/2 && mouseY > height/2) trueColor = true; else trueColor = false; // Color indicator highlights
  if (mouseX > width/2 && mouseY > height/2) falseColor  = true; else falseColor  = false;
  
  // True / False text //
  fill(250);
  noStroke();
  triangle(width/2-50*scaleY,height*0.75f, width/2,height*0.75f-50*scaleY, width/2,height*0.75f+50*scaleY);  // Left arrow background 
  triangle(width/2+50*scaleY,height*0.75f, width/2,height*0.75f-50*scaleY, width/2,height*0.75f+50*scaleY);  // Right arrow background

  textAlign(CENTER);
  textFont(GilroyLight);  
  textSize(textLarge);
  fill(100); 
  stroke(100);
  strokeWeight(strokeLarge);
  text("True", width/4, height*0.75f+textLarge*0.3f);  // True
  noStroke();
  if (trueColor) {fill(0xffFF9090, 150);} else {fill(0xff90FF9C, 150);}  // Highlight
  triangle(width/2-50*scaleY,height*0.75f, width/2,height*0.75f-50*scaleY, width/2,height*0.75f+50*scaleY);  // Left arrow
  
  fill(100);
  stroke(100);
  strokeWeight(strokeLarge);
  text("False", width/4*3, height*0.75f+textLarge*0.3f);  // False
  noStroke();
  if (falseColor) {fill(0xff90FF9C, 150);} else {fill(0xffFF9090, 150);}  // Highlight
  triangle(width/2+50*scaleY,height*0.75f, width/2,height*0.75f-50*scaleY, width/2,height*0.75f+50*scaleY);  // Right arrow
  
  // if (trueColor == true && falseColor == false) {fill(#FF9090);} else if(falseColor == true && trueColor == false) {fill(#90FF9C);} else {fill(#FF9090);} // Highlight
  drawPuzzle();  // Draws the puzzle.
  
  // Timer bar //
  strokeWeight(strokeLarge);
  stroke(pColor);
  line(strokeLarge*2,height/2-strokeLarge*1.5f, timerX,height/2-strokeLarge*1.5f);
  timer -= 1.0f/60;  // Timer decrease by 1 every second
  timerX = map(timer, 0,countdown, strokeLarge*2,width-strokeLarge*2);
  if (timerX <= strokeLarge*2) {mode = GAMEOVER;}  // Ran out of time!
  
  if (match) {  // Color matches word
    if (yes) {initPuzzle(); score += 1;} else if(no) {mode = GAMEOVER;}
  } else {  // Color does not match word
    if (yes) {mode = GAMEOVER;} else if(no) {initPuzzle(); score += 1;}
  }
  if (score > highscore) highscore = score;  // Update highscore
}
public void gameover() {
  background(240);
  fill(100);
  textAlign(CENTER);
  textFont(GilroyBold);
  textSize(textLarge);
  text("Game Over!", width/2, height/3+textLarge);
  textFont(GilroyLight);
  textSize(textLarge/2);
  text("Score: "+score, width/2, height/2+textLarge/4);
  text("Highscore: "+highscore, width/2, height/2+textLarge/2+textLarge/4);
  textSize(textLarge/3);
  text("[space] -> main menu", width/2, height/3*2);
  
  if (space) {space = false; score = 0; initPuzzle(); mode = INTRO;} // Checks for space press to return to main menu
}

public void intro() {
  //background(240);  // This will be replaced with an Animated Gif background!
  imageMode(CENTER);
  image(gif[loadFrame], width/2,height/2, width,width*(0.75f));  // width,width*(0.75) scales the gif to the screen width, while keeping the original aspect ratio (800x600) (1x0.75)
  loadFrame += 1;
  if (loadFrame == 72) loadFrame += 1;  // Skip frame 72 because it broke
  if (loadFrame == frames) loadFrame = 0;
  
  rectMode(CENTER);
  fill(255,50);
  rect(width/2,height/2, width,height);  // Background blur over GIF
  
  fill(0, 75);  // Box
  noStroke();
  rect(width/2,height/2, width,textLarge*1.8f);
  rect(width/2,height-((50+strokeLarge)*scaleY), 500*scaleX,100*scaleY, strokeLarge/2);
  
  fill(255);  // Title
  textAlign(CENTER);
  textFont(GilroyBold);
  textSize(textLarge);
  text("colorGame();", width/2, height/2+15*scaleY);
  textFont(GilroyLight);
  textSize(textLarge/3);
  text("[space] -> start", width/2, height/2+50*scaleY);
  text("controls:\n[left arrow] / [click] / [right arrow]", width/2, height-textLarge);
  
  if (space) {space = false; mode = GAME;}  // Checks for space press to start game
  
}
public void paused() {
  background(240);
  fill(100);
  textAlign(CENTER);
  textFont(GilroyBold);
  textSize(textLarge);
  text("pause();", width/2, height/2+15*scaleY);
  textFont(GilroyLight);
  textSize(textLarge/3);
  text("switch back to this window to resume", width/2, height/2+50*scaleY);
  
  if(focused) {mode=GAME;}
}
  public void settings() {  size(1000,700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ColorGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
